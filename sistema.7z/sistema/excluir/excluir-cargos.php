<?php
include_once './include/logado.php';
include_once './include/conexao.php';

// verifica
$id = isset($_GET['id']) ? $_GET['id'] : null;
// consulta p excluir o cargo
if ($id){

    $sql = "DELETE FROM cargos WHERE CargoID = $id";

    if ($conn->query($sql)){

        header("location: lista-cargos.php");
        exit();

        } else {

            echo "Erro: " . $conn->error;

        } else{

            echo "Id não encontrado.";

        }
    }

?>